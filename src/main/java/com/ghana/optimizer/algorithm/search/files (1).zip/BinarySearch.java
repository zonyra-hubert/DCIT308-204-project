package com.ghana.optimizer.algorithms.search;

/**
 * Binary Search
 * -----------------------------------------------------------------------
 * UG-CSOO System — Search Algorithms Module
 *
 * Baseline O(log n) search used as the performance comparison point
 * against InterpolationSearch. Implemented iteratively over plain
 * arrays — no java.util collection types.
 * -----------------------------------------------------------------------
 */
public final class BinarySearch {

    private BinarySearch() {
        // static utility class — no instances
    }

    public static int search(long[] sortedIds, long targetId) {
        if (sortedIds == null || sortedIds.length == 0) {
            return -1;
        }

        int low = 0;
        int high = sortedIds.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            long midVal = sortedIds[mid];

            if (midVal == targetId) {
                return mid;
            } else if (midVal < targetId) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }

    public static int search(double[] sortedBudgets, double targetBudget, double epsilon) {
        if (sortedBudgets == null || sortedBudgets.length == 0) {
            return -1;
        }

        int low = 0;
        int high = sortedBudgets.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            double diff = sortedBudgets[mid] - targetBudget;

            if (Math.abs(diff) <= epsilon) {
                return mid;
            } else if (diff < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }
}
