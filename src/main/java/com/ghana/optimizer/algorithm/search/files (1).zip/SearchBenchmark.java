package com.ghana.optimizer.benchmark;

import com.ghana.optimizer.algorithms.search.BinarySearch;
import com.ghana.optimizer.algorithms.search.InterpolationSearch;

import java.util.Random;

/**
 * SearchBenchmark
 * -----------------------------------------------------------------------
 * UG-CSOO System — Algorithm Performance Verification
 *
 * Compares Interpolation Search against Binary Search on uniformly
 * distributed, sorted datasets of ticket IDs and budget values, at
 * increasing sizes on a logarithmic scale (10^2 ... 10^7). This
 * mirrors how the two algorithms would behave as the campus's
 * service_requests table grows from hundreds of records today toward
 * a much larger archive.
 *
 * Each size is benchmarked with:
 *   - a warm-up pass (JIT warm-up, discarded from timing)
 *   - TRIALS_PER_SIZE independent random target lookups
 *   - a mix of "hit" targets (values that exist in the array) and
 *     "miss" targets (values that don't), matched by index reuse so
 *     both algorithms see the identical query sequence
 *
 * Only java.util.Random is used here (a utility class, not a
 * collection), consistent with the "no java.util collection
 * frameworks" constraint that applies to CustomHashTable / DynamicArray
 * elsewhere in the project. Datasets themselves are plain long[]/double[]
 * arrays.
 *
 * Run standalone with:
 *   javac com/ghana/optimizer/algorithms/search/*.java com/ghana/optimizer/benchmark/SearchBenchmark.java
 *   java com.ghana.optimizer.benchmark.SearchBenchmark
 * -----------------------------------------------------------------------
 */
public final class SearchBenchmark {

    // Dataset sizes on a logarithmic scale: 10^2 -> 10^7
    private static final int[] DATASET_SIZES = {
            100, 1_000, 10_000, 100_000, 1_000_000, 10_000_000
    };

    private static final int TRIALS_PER_SIZE = 50_000;
    private static final double BUDGET_EPSILON = 0.001;
    private static final long SEED = 42L; // fixed seed -> reproducible results

    public static void main(String[] args) {
        printBanner();
        runIdBenchmark();
        runBudgetBenchmark();
    }

    // ---------------------------------------------------------------
    // Ticket ID benchmark (long[], uniformly spaced integers)
    // ---------------------------------------------------------------
    private static void runIdBenchmark() {
        System.out.println();
        System.out.println("== Benchmark 1: Ticket ID Lookup (uniformly distributed longs) ==");
        printIdHeader();

        for (int size : DATASET_SIZES) {
            long[] ids = generateUniformSortedIds(size, SEED);
            Random queryRandom = new Random(SEED + size);

            // Build a matched query sequence: 70% hits, 30% misses,
            // used identically for both algorithms.
            long[] queries = buildIdQueries(ids, queryRandom, TRIALS_PER_SIZE);

            // Warm-up (discarded)
            timeIdSearches(InterpolationSearch::search, ids, queries);
            timeIdSearches(BinarySearch::search, ids, queries);

            long interpNanos = timeIdSearches(InterpolationSearch::search, ids, queries);
            long binaryNanos = timeIdSearches(BinarySearch::search, ids, queries);

            printRow(size, interpNanos, binaryNanos);
        }
    }

    // ---------------------------------------------------------------
    // Budget benchmark (double[], uniformly spread currency amounts)
    // ---------------------------------------------------------------
    private static void runBudgetBenchmark() {
        System.out.println();
        System.out.println("== Benchmark 2: Budget Lookup (uniformly distributed doubles, GHS) ==");
        printBudgetHeader();

        for (int size : DATASET_SIZES) {
            double[] budgets = generateUniformSortedBudgets(size, SEED);
            Random queryRandom = new Random(SEED + size);

            double[] queries = buildBudgetQueries(budgets, queryRandom, TRIALS_PER_SIZE);

            // Warm-up (discarded)
            timeBudgetSearches(InterpolationSearch::search, budgets, queries);
            timeBudgetSearches(BinarySearch::search, budgets, queries);

            long interpNanos = timeBudgetSearches(InterpolationSearch::search, budgets, queries);
            long binaryNanos = timeBudgetSearches(BinarySearch::search, budgets, queries);

            printRow(size, interpNanos, binaryNanos);
        }
    }

    // ---------------------------------------------------------------
    // Timing helpers
    // ---------------------------------------------------------------

    @FunctionalInterface
    private interface IdSearchFn {
        int search(long[] arr, long target);
    }

    @FunctionalInterface
    private interface BudgetSearchFn {
        int search(double[] arr, double target, double epsilon);
    }

    private static long timeIdSearches(IdSearchFn fn, long[] ids, long[] queries) {
        long start = System.nanoTime();
        for (long q : queries) {
            fn.search(ids, q);
        }
        return System.nanoTime() - start;
    }

    private static long timeBudgetSearches(BudgetSearchFn fn, double[] budgets, double[] queries) {
        long start = System.nanoTime();
        for (double q : queries) {
            fn.search(budgets, q, BUDGET_EPSILON);
        }
        return System.nanoTime() - start;
    }

    // ---------------------------------------------------------------
    // Dataset generation (plain arrays, no java.util collections)
    // ---------------------------------------------------------------

    /** Uniformly spaced ascending IDs, e.g. simulating service_requests.id at scale. */
    private static long[] generateUniformSortedIds(int size, long seed) {
        long[] ids = new long[size];
        Random rnd = new Random(seed);
        long current = 1000; // starting ticket ID
        for (int i = 0; i < size; i++) {
            // small uniform gaps (1-5) keep the array strictly increasing
            // and uniformly distributed, mirroring near-sequential ticket IDs
            current += 1 + rnd.nextInt(5);
            ids[i] = current;
        }
        return ids;
    }

    /** Uniformly distributed ascending budgets bounded by the GHS 1,089.00 constraint scaled to dataset size. */
    private static double[] generateUniformSortedBudgets(int size, long seed) {
        double[] budgets = new double[size];
        Random rnd = new Random(seed + 1);
        double maxBudget = 1089.0 * Math.max(1, size / 100.0); // scale range with size, stays uniform
        for (int i = 0; i < size; i++) {
            budgets[i] = rnd.nextDouble() * maxBudget;
        }
        java.util.Arrays.sort(budgets); // sorting utility only — not a collection type
        return budgets;
    }

    private static long[] buildIdQueries(long[] ids, Random rnd, int count) {
        long[] queries = new long[count];
        for (int i = 0; i < count; i++) {
            if (rnd.nextDouble() < 0.7) {
                // hit: pick an existing ID
                queries[i] = ids[rnd.nextInt(ids.length)];
            } else {
                // miss: value guaranteed outside range or between gaps
                queries[i] = ids[ids.length - 1] + 1 + rnd.nextInt(1000);
            }
        }
        return queries;
    }

    private static double[] buildBudgetQueries(double[] budgets, Random rnd, int count) {
        double[] queries = new double[count];
        for (int i = 0; i < count; i++) {
            if (rnd.nextDouble() < 0.7) {
                queries[i] = budgets[rnd.nextInt(budgets.length)];
            } else {
                queries[i] = budgets[budgets.length - 1] + 1 + rnd.nextDouble() * 1000;
            }
        }
        return queries;
    }

    // ---------------------------------------------------------------
    // Console output formatting (matches UG-CSOO console mock style)
    // ---------------------------------------------------------------

    private static void printBanner() {
        System.out.println("==========================================================================");
        System.out.println("  UG-CSOO Search Algorithm Benchmark");
        System.out.println("  Interpolation Search vs Binary Search — Uniformly Distributed Data");
        System.out.println("  Trials per dataset size: " + TRIALS_PER_SIZE);
        System.out.println("==========================================================================");
    }

    private static void printIdHeader() {
        System.out.printf("%-12s %-22s %-22s %-12s%n",
                "Dataset N", "Interpolation (ms)", "Binary Search (ms)", "Speedup");
        System.out.println("--------------------------------------------------------------------------");
    }

    private static void printBudgetHeader() {
        printIdHeader();
    }

    private static void printRow(int size, long interpNanos, long binaryNanos) {
        double interpMs = interpNanos / 1_000_000.0;
        double binaryMs = binaryNanos / 1_000_000.0;
        double speedup = binaryMs / interpMs;
        System.out.printf("%-12d %-22.3f %-22.3f %-12.2fx%n", size, interpMs, binaryMs, speedup);
    }
}
