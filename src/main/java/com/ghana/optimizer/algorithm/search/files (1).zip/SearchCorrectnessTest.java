package com.ghana.optimizer.algorithms.search;

import java.util.Random;

/**
 * SearchCorrectnessTest
 * -----------------------------------------------------------------------
 * Quick self-contained correctness check for InterpolationSearch and
 * BinarySearch: both must agree with each other, and both must agree
 * with a naive linear scan, on random datasets and edge cases (empty
 * array, single element, target below/above range, duplicate-free
 * uniform data with gaps).
 *
 * Run with:
 *   java com.ghana.optimizer.algorithms.search.SearchCorrectnessTest
 * -----------------------------------------------------------------------
 */
public final class SearchCorrectnessTest {

    private static int failures = 0;
    private static int checks = 0;

    public static void main(String[] args) {
        testEmptyArray();
        testSingleElement();
        testOutOfRangeTargets();
        testRandomizedAgreement();

        System.out.println();
        if (failures == 0) {
            System.out.println("ALL " + checks + " CHECKS PASSED.");
        } else {
            System.out.println(failures + " / " + checks + " CHECKS FAILED.");
            System.exit(1);
        }
    }

    private static void testEmptyArray() {
        long[] empty = new long[0];
        assertEquals("empty array id search", -1, InterpolationSearch.search(empty, 5));
        assertEquals("empty array id search (binary)", -1, BinarySearch.search(empty, 5));
    }

    private static void testSingleElement() {
        long[] one = {42};
        assertEquals("single element hit", 0, InterpolationSearch.search(one, 42));
        assertEquals("single element miss", -1, InterpolationSearch.search(one, 7));
    }

    private static void testOutOfRangeTargets() {
        long[] ids = {1000, 1004, 1009, 1015, 1020};
        assertEquals("below range", -1, InterpolationSearch.search(ids, 500));
        assertEquals("above range", -1, InterpolationSearch.search(ids, 5000));
        assertEquals("in a gap", -1, InterpolationSearch.search(ids, 1006));
        assertEquals("exact hit", 2, InterpolationSearch.search(ids, 1009));
    }

    private static void testRandomizedAgreement() {
        Random rnd = new Random(7);
        for (int trial = 0; trial < 200; trial++) {
            int size = 1 + rnd.nextInt(5000);
            long[] ids = new long[size];
            long current = rnd.nextInt(100);
            for (int i = 0; i < size; i++) {
                current += 1 + rnd.nextInt(4);
                ids[i] = current;
            }

            for (int q = 0; q < 20; q++) {
                long target = (rnd.nextBoolean())
                        ? ids[rnd.nextInt(size)]                       // guaranteed hit
                        : current + 1 + rnd.nextInt(1000);             // guaranteed miss

                int interpResult = InterpolationSearch.search(ids, target);
                int binaryResult = BinarySearch.search(ids, target);
                int linearResult = linearSearch(ids, target);

                assertEquals("trial " + trial + " interp==linear", linearResult, interpResult);
                assertEquals("trial " + trial + " binary==linear", linearResult, binaryResult);
            }
        }
    }

    private static int linearSearch(long[] arr, long target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) return i;
        }
        return -1;
    }

    private static void assertEquals(String label, int expected, int actual) {
        checks++;
        if (expected != actual) {
            failures++;
            System.out.println("FAIL [" + label + "]: expected " + expected + " but got " + actual);
        }
    }
}
